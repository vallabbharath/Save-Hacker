var baseurl="http://dotsit.in/parking/api/";
//var baseurl="http://localhost/app/api/";
//var baseurl="http://in1947.net/restaurant/foodysrest/";

var clientid=1;
